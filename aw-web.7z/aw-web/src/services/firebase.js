import firebase from 'firebase';

import 'firebase/database';

var firebaseConfig = {
    apiKey: "AIzaSyBv6yYrk-6JMIf1CdNVCOq3qV7GMRqJJ1Y",
    authDomain: "aw-web-dc5de.firebaseapp.com",
    databaseURL: "https://aw-web-dc5de.firebaseio.com",
    projectId: "aw-web-dc5de",
    storageBucket: "aw-web-dc5de.appspot.com",
    messagingSenderId: "479257062931",
    appId: "1:479257062931:web:980be080268bb2cf5759e6"
  };
  
  firebase.initializeApp(firebaseConfig);

  export default firebase;